package edu.unsada.yimeil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YimeilApplication {

	public static void main(String[] args) {
		SpringApplication.run(YimeilApplication.class, args);
	}

}
